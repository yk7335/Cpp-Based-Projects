I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work. On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Your Name: Yash Kalyani                  Date: 2/28/2020

Name: Yash Kalyani
UIN: 827003754
Email: yk7335@tamu.edu
Section: 511
Resources:
http://mitk.org/images/c/ca/MoveConstructor.pdf
https://www.softwaretestinghelp.com/doubly-linked-list/

Known Problems:
There weren't any problems with my code except syntax errors which I fixed. The only thing I had trouble with is
remembering which constructor did what.
Short Description of Code:
This code contains a sentinel node Doubly linked list of type int and has functions such as insert before, after and ect...
Testing:
I ran the main cpp and tested to see if my function worked properly. I made test cases for the functions that the test cases
that were not given to me.
