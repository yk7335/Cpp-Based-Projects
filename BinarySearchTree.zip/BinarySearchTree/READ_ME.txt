These files contain a binary search tree data structure. The code populates a binary search tree with values given
from text files which are provided. The binary search tree class has constructors, all copy and move assignment,
tree printing functions, sorting functions (topoplogical sort), and search costing functions. This assingment provided 
experience with Binary search trees and algorithms that go with them such as DFS, BFS, Topological sort, ect...

Running Instructions: 
	After downloading run the makefile to execute the main file. 
	The program takes input from data files which are provided in data_files folder.

