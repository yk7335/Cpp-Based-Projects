I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work. On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Your Name: Yash Kalyani                  Date: 1/22/2020

Name: Yash Kalyani
UIN: 827003754
Email: yk7335@tamu.edu
Section: 511
Resources:
  https://www.toptal.com/developers/sorting-algorithms
  http://www.cplusplus.com/doc/tutorial/files/
Known Problems:
During the code I had problems with the istream operator << because I wasn't sure how to
do the code syntactically but logically I knew what do or I knew what the operator was suppose to
do. I also had problems in my main when I was trying to read the file and store them in my object,
again this was because of syntax so with the help of google and other websites I was able to figure out
how to code it.

Short Description of Code:
The code has a class collection or array of stress balls with a size of ball and color of ball.
The code makes changes to the array of stress balls such as reading in stress balls from a .data file.
It combines two collections or arrays of stress balls together; swaps them.... etc...

Testing:
I ran most of the functions in my collection_test cpp file. I made sure that my major functions
(bubble sort, selection sort, insertion sort, union, and swap) did their jobs.

How to run Program:
Run the makefile