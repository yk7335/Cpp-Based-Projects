Topic: Grpahs

Description:
I implemented a graph class which held two private variables and 7 functions including the constructor and
destructor. The first of the two private variables is a called node_list and is vector of type Vertex, Vertex is a struct with
contains the label, indegree, and topological ordering number for each node in the graph, In simpler terms node_list is a
vector which holds each node of the graph and it’s important information. The second private variable is adj_list and it is
a vector of a pointer type and this pointer of type list which is of type int. This means that our vector holds a bunch of
pointers that point to lists and these lists contains the outdegree of each node which is read from a file. We used
vectors, list, fstream, iostream, and namespace std to take inputs in and create variable and place the inputs inside the
variables. The functions that were implemented were buildGraph, DisplayGraph, topological_sort, compute_indegree, and print_top_sort.

Testing:
The program reads data from files the outputs te vertex and indegree of the graph and also it's topological sort order.
Data files are given to show the format they need to be in.  

How to run:
Run the code by typing make (Run the makefile) and then ./main _________ (the ______ is the input file name!)

