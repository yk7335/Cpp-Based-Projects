// topological sort

#include <iostream>
#include "graph.h"

void Graph::compute_indegree()
{
	// vector<int> temp(node_list.size());
	// for(int i= 0; i < node_list.size(); i++){
	// 	auto it = adj_list[i]->begin();
 //      	while(it!=adj_list[i]->end()){
 //      		temp[*it]+=1;
 //      		++it;
 //      	}
	// }
	// int j=0;
	// auto jt = adj_list[j]->begin();
 //    while(jt!=adj_list[j]->end()){
 //      	cout << temp[j] << endl;
 //      	++jt;
 //      	j++;
 //      }
	for(int i = 0; i < this->node_list.size() - 1; i++)
    {
        for(auto it = this->adj_list.at(i)->begin(); it != this->adj_list.at(i)->end(); it++)
        	{node_list.at(*it-1).indegree++;}
	}

	// for(int i = 0; i<this->node_list.size()-1;i++)
 //    {
 //        cout<<" vertex : "<<node_list.at(i).label<<" indegree : "<<node_list.at(i).indegree<<endl;
 //    }

}

void Graph::topological_sort()
{
  // to be implemented.
	int temp = 0;
	vector<Vertex> nodeList = node_list;
    list<Vertex*> Node1;
    Node1.clear();
    for(int i =0; i <node_list.size()-1;i++)
    {
        if(node_list.at(i).indegree == 0)
        {
            Node1.push_back(&node_list[i]);
        }
    }
    while(!Node1.empty())
    {
        Vertex* Node2 = Node1.front();
        Node1.pop_front();
        Node2->top_num = ++temp;
        
        for(auto it = this->adj_list.at(Node2->label-1)->begin(); it != this->adj_list.at(Node2->label-1)->end(); it++)
        {
            if(--(node_list.at( (*it)-1).indegree) == 0)
            {Node1.push_back(&node_list.at( (*it)-1));}
        }
    }
    for(int i = 0; i < nodeList.size(); i++)
    {
      node_list.at(i).indegree = nodeList.at(i).indegree;
    }
    
    try
    {
        if(temp != node_list.size()-1)
        {
            throw 0;
        }
    }
    catch(int Node2)
    {
        cout<<"There was a cycle found"<<endl;
    }
}

void Graph::print_top_sort()
{
  // to be implemented
	int temp = 0;
    while(temp != node_list.size())
    {
        for(int i =0; i<node_list.size()-1;i++)
        {
            if(node_list[i].top_num == temp)
            {
                cout << node_list[i].label<<" ";
            }
        }
        temp += 1;
    }
}