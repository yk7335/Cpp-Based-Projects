#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <list>
using namespace std;

// int main(){
// 	vector<int> list;
// 	string num;
// 	ifstream Temp;
// 	Temp.open("input.data");

// // Use a while loop together with the getline() function to read the file line by line
// 	while (getline(Temp, num)) {
//   // Output the text from the file
// 		cout << num[0];
//   		cout << num <<  endl;
//   		int i = 0;
//   		while(num[i] != '-'){
//   			list.push_back((int)num[i]);
//   			i+=2;
//   		}
//   		num = "";
// }
// // Close the file
// for(int i = 0; i < list.size(); i++){
// 	cout << list[i] << " 0";
// }
// Temp.close();


// cout << endl; 
// cout << endl;

// }


int main(){
	//vector<list<int>*> list;
	vector<list<int>> list;
	int num;
	ifstream Temp;
	Temp.open("input.data");
	int i = 0;
// Use a while loop together with the getline() function to read the file line by line
	while (!Temp.eof()) {
  // Output the text from the file
		Temp >> num;
		cout << num << endl;
		if(num!=-1){
			//list.at(i)->push_back(num);
			list.at(i).push_back(num);
		}else{
			i++;
		}
		
}
// Close the file
Temp.close();

cout << endl; 
cout << endl;

// for(int i=0; i < list.size(); i++){
// 	cout << list[i] << "   ,    ";
// }
}